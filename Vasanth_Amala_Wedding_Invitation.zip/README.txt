VASANTH & AMALA CHRISTY - WEDDING INVITATION WEBSITE

1. Open index.html in Chrome to preview the invitation.
2. Use the photo selectors to preview the bride and groom photos.
3. Use the audio selector to preview an audio file you have permission to use.
4. The photo and music selections are local previews only; they are not embedded in the website file.
5. To publish online, upload index.html to a GitHub repository and enable GitHub Pages.

Wedding details currently included:
Groom: Vasanth
Bride: Amala Christy
Date: 20 January 2027
Time: 6:30 AM
Venue: Komarapalayam Church

The requested song is not included. Add your own legally obtained audio file in the page's music selector.
